import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/shortcut.dart';

class ShortcutService {
  static const String _key = 'dest_os_shortcuts';

  Future<List<ShortcutItem>> getShortcuts(String category) async {
    final prefs = await SharedPreferences.getInstance();
    final String? data = prefs.getString(_key);
    if (data == null) return [];

    final List list = jsonDecode(data);
    return list
        .map((e) => ShortcutItem.fromJson(e))
        .where((s) => s.category == category)
        .toList();
  }

  Future<void> addShortcut(ShortcutItem item) async {
    final prefs = await SharedPreferences.getInstance();
    final String? data = prefs.getString(_key);
    List list = data != null ? jsonDecode(data) : [];

    // Aynı id varsa ekleme
    if (list.any((e) => e['id'] == item.id)) return;

    list.add(item.toJson());
    await prefs.setString(_key, jsonEncode(list));
  }

  Future<void> removeShortcut(String id) async {
    final prefs = await SharedPreferences.getInstance();
    final String? data = prefs.getString(_key);
    if (data == null) return;

    List list = jsonDecode(data);
    list.removeWhere((e) => e['id'] == id);
    await prefs.setString(_key, jsonEncode(list));
  }

  // Örnek uygulamalar (gerçek cihaz uygulamaları yerine)
  static List<ShortcutItem> getAvailableApps(String category) {
    final all = [
      // SOSYAL
      ShortcutItem(id: 'whatsapp', name: 'WhatsApp', icon: '💬', category: 'SOSYAL'),
      ShortcutItem(id: 'instagram', name: 'Instagram', icon: '📸', category: 'SOSYAL'),
      ShortcutItem(id: 'telegram', name: 'Telegram', icon: '✈️', category: 'SOSYAL'),
      ShortcutItem(id: 'twitter', name: 'X (Twitter)', icon: '🐦', category: 'SOSYAL'),
      ShortcutItem(id: 'facebook', name: 'Facebook', icon: '👤', category: 'SOSYAL'),
      ShortcutItem(id: 'tiktok', name: 'TikTok', icon: '🎵', category: 'SOSYAL'),

      // ARES
      ShortcutItem(id: 'ares_ai', name: 'ARES AI', icon: '👁️', category: 'ARES'),
      ShortcutItem(id: 'ares_chat', name: 'ARES Chat', icon: '🤖', category: 'ARES'),
      ShortcutItem(id: 'ares_vision', name: 'ARES Vision', icon: '🔍', category: 'ARES'),

      // MEDYA
      ShortcutItem(id: 'youtube', name: 'YouTube', icon: '▶️', category: 'MEDYA'),
      ShortcutItem(id: 'netflix', name: 'Netflix', icon: '🎬', category: 'MEDYA'),
      ShortcutItem(id: 'spotify', name: 'Spotify', icon: '🎧', category: 'MEDYA'),
      ShortcutItem(id: 'gallery', name: 'Galeri', icon: '🖼️', category: 'MEDYA'),
      ShortcutItem(id: 'camera', name: 'Kamera', icon: '📷', category: 'MEDYA'),

      // ARAÇLAR
      ShortcutItem(id: 'calculator', name: 'Hesap Makinesi', icon: '🧮', category: 'ARAÇLAR'),
      ShortcutItem(id: 'notes', name: 'Notlar', icon: '📝', category: 'ARAÇLAR'),
      ShortcutItem(id: 'files', name: 'Dosyalar', icon: '📁', category: 'ARAÇLAR'),
      ShortcutItem(id: 'flashlight', name: 'El Feneri', icon: '🔦', category: 'ARAÇLAR'),
      ShortcutItem(id: 'compass', name: 'Pusula', icon: '🧭', category: 'ARAÇLAR'),

      // İŞ
      ShortcutItem(id: 'gmail', name: 'Gmail', icon: '📧', category: 'İŞ'),
      ShortcutItem(id: 'drive', name: 'Google Drive', icon: '☁️', category: 'İŞ'),
      ShortcutItem(id: 'docs', name: 'Belgeler', icon: '📄', category: 'İŞ'),
      ShortcutItem(id: 'calendar', name: 'Takvim', icon: '📅', category: 'İŞ'),
      ShortcutItem(id: 'meet', name: 'Google Meet', icon: '📹', category: 'İŞ'),

      // SİSTEM
      ShortcutItem(id: 'settings', name: 'Ayarlar', icon: '⚙️', category: 'SİSTEM'),
      ShortcutItem(id: 'wifi', name: 'Wi-Fi', icon: '📶', category: 'SİSTEM'),
      ShortcutItem(id: 'bluetooth', name: 'Bluetooth', icon: '🔵', category: 'SİSTEM'),
      ShortcutItem(id: 'battery', name: 'Batarya', icon: '🔋', category: 'SİSTEM'),
      ShortcutItem(id: 'display', name: 'Ekran', icon: '🖥️', category: 'SİSTEM'),

      // İNTERNET
      ShortcutItem(id: 'chrome', name: 'Chrome', icon: '🌐', category: 'İNTERNET'),
      ShortcutItem(id: 'maps', name: 'Haritalar', icon: '🗺️', category: 'İNTERNET'),
      ShortcutItem(id: 'translate', name: 'Çeviri', icon: '🔤', category: 'İNTERNET'),
      ShortcutItem(id: 'store', name: 'Play Store', icon: '🛍️', category: 'İNTERNET'),

      // DİĞER
      ShortcutItem(id: 'clock', name: 'Saat', icon: '⏰', category: 'DİĞER'),
      ShortcutItem(id: 'weather', name: 'Hava Durumu', icon: '🌤️', category: 'DİĞER'),
      ShortcutItem(id: 'phone', name: 'Telefon', icon: '📞', category: 'DİĞER'),
      ShortcutItem(id: 'messages', name: 'Mesajlar', icon: '💬', category: 'DİĞER'),
      ShortcutItem(id: 'contacts', name: 'Rehber', icon: '👥', category: 'DİĞER'),
    ];

    return all.where((a) => a.category == category).toList();
  }
}
