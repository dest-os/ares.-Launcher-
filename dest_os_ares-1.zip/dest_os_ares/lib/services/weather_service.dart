import 'dart:convert';
import 'package:http/http.dart' as http;

class WeatherData {
  final double temp;
  final double feelsLike;
  final int humidity;
  final double windSpeed;
  final String description;
  final String icon;
  final String city;
  final DateTime updatedAt;

  WeatherData({
    required this.temp,
    required this.feelsLike,
    required this.humidity,
    required this.windSpeed,
    required this.description,
    required this.icon,
    required this.city,
    required this.updatedAt,
  });
}

class WeatherService {
  // BURAYA KENDİ API KEY'İNİ YAZ
  // https://openweathermap.org/api adresinden ücretsiz alabilirsin
  static const String apiKey = 'BURAYA_API_KEY_YAZ';

  // İstanbul koordinatları
  static const double lat = 41.0082;
  static const double lon = 28.9784;

  Future<WeatherData?> getWeather() async {
    if (apiKey == 'BURAYA_API_KEY_YAZ' || apiKey.isEmpty) {
      // API key yoksa örnek veri döndür
      return WeatherData(
        temp: 24,
        feelsLike: 26,
        humidity: 58,
        windSpeed: 12,
        description: 'Parçalı Bulutlu',
        icon: '02d',
        city: 'İstanbul',
        updatedAt: DateTime.now(),
      );
    }

    try {
      final url = Uri.parse(
        'https://api.openweathermap.org/data/2.5/weather?lat=$lat&lon=$lon&appid=$apiKey&units=metric&lang=tr',
      );

      final response = await http.get(url);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return WeatherData(
          temp: (data['main']['temp'] as num).toDouble(),
          feelsLike: (data['main']['feels_like'] as num).toDouble(),
          humidity: data['main']['humidity'],
          windSpeed: (data['wind']['speed'] as num).toDouble() * 3.6, // m/s -> km/h
          description: data['weather'][0]['description'],
          icon: data['weather'][0]['icon'],
          city: data['name'],
          updatedAt: DateTime.now(),
        );
      }
    } catch (e) {
      print('Hava durumu hatası: $e');
    }
    return null;
  }
}
