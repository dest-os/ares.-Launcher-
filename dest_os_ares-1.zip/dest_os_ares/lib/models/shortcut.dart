class ShortcutItem {
  final String id;
  final String name;
  final String icon; // emoji veya ikon adı
  final String category;

  ShortcutItem({
    required this.id,
    required this.name,
    required this.icon,
    required this.category,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'icon': icon,
        'category': category,
      };

  factory ShortcutItem.fromJson(Map<String, dynamic> json) => ShortcutItem(
        id: json['id'],
        name: json['name'],
        icon: json['icon'],
        category: json['category'],
      );
}
