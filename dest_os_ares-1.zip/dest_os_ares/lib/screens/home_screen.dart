import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../widgets/clock_widget.dart';
import '../widgets/status_bar_widget.dart';
import '../widgets/calendar_widget.dart';
import '../widgets/weather_widget.dart';
import '../widgets/category_button.dart';
import '../widgets/neon_container.dart';
import '../widgets/shortcut_sheet.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  void _openCategory(BuildContext context, String category) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => ShortcutSheet(category: category),
    );
  }

  void _openAdd(BuildContext context, String category) {
    _openCategory(context, category);
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final isTablet = size.shortestSide >= 600;
    final isLandscape = size.width > size.height;

    final categories = [
      {'title': 'SOSYAL', 'icon': Icons.groups},
      {'title': 'ARES', 'icon': Icons.remove_red_eye},
      {'title': 'MEDYA', 'icon': Icons.play_circle_filled},
      {'title': 'ARAÇLAR', 'icon': Icons.build},
      {'title': 'İŞ', 'icon': Icons.work},
      {'title': 'SİSTEM', 'icon': Icons.settings},
      {'title': 'İNTERNET', 'icon': Icons.language},
      {'title': 'DİĞER', 'icon': Icons.apps},
    ];

    return Scaffold(
      backgroundColor: const Color(0xFF02050A),
      body: Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment(0, -0.3),
            radius: 1.4,
            colors: [
              Color(0xFF0A1A2F),
              Color(0xFF02050A),
            ],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: EdgeInsets.symmetric(
              horizontal: isTablet ? 24 : 10,
              vertical: isTablet ? 12 : 6,
            ),
            child: Column(
              children: [
                // Üst bar
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: const [
                    ClockWidget(),
                    StatusBarWidget(),
                  ],
                ),

                SizedBox(height: isTablet ? 16 : 8),

                // Ana içerik
                Expanded(
                  child: isTablet && isLandscape
                      ? _buildTabletLandscapeLayout(context, categories)
                      : _buildPhoneLayout(context, categories),
                ),

                // Android navigasyon çubuğu
                Container(
                  height: isTablet ? 56 : 48,
                  margin: EdgeInsets.only(
                    top: isTablet ? 12 : 6,
                    bottom: isTablet ? 8 : 4,
                    left: isTablet ? 80 : 20,
                    right: isTablet ? 80 : 20,
                  ),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(28),
                    border: Border.all(color: const Color(0xFF00BFFF).withOpacity(0.4)),
                    color: Colors.black.withOpacity(0.4),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Icon(Icons.arrow_back_ios_new, color: Colors.white.withOpacity(0.7), size: isTablet ? 24 : 20),
                      Container(
                        width: isTablet ? 22 : 18,
                        height: isTablet ? 22 : 18,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(color: Colors.white.withOpacity(0.7), width: 2),
                        ),
                      ),
                      Icon(Icons.crop_square, color: Colors.white.withOpacity(0.7), size: isTablet ? 24 : 20),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // Telefon / dikey düzen
  Widget _buildPhoneLayout(BuildContext context, List categories) {
    return Column(
      children: [
        Expanded(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Sol
              Expanded(
                flex: 3,
                child: Column(
                  children: [
                    _buildAvatar('https://i.pravatar.cc/150?img=5', size: 85),
                    const SizedBox(height: 10),
                    const Expanded(child: CalendarWidget()),
                  ],
                ),
              ),
              // Orta
              Expanded(
                flex: 4,
                child: Column(
                  children: [
                    const SizedBox(height: 6),
                    _buildLogo(size: 100),
                    const SizedBox(height: 12),
                    NeonContainer(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
                      borderRadius: 18,
                      child: Text(
                        'DEST-OS ARES',
                        style: GoogleFonts.orbitron(
                          color: const Color(0xFF00BFFF),
                          fontSize: 13,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.5,
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    _buildUserName(),
                  ],
                ),
              ),
              // Sağ
              Expanded(
                flex: 3,
                child: Column(
                  children: [
                    _buildAvatar('https://i.pravatar.cc/150?img=12', size: 85),
                    const SizedBox(height: 10),
                    const Expanded(child: WeatherWidget()),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 10),
        // Kategoriler
        Row(
          children: categories.map((cat) {
            return Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 3),
                child: CategoryButton(
                  title: cat['title'] as String,
                  icon: cat['icon'] as IconData,
                  onTap: () => _openCategory(context, cat['title'] as String),
                  onAdd: () => _openAdd(context, cat['title'] as String),
                ),
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  // Tablet yatay düzen (14.3 inç için optimize)
  Widget _buildTabletLandscapeLayout(BuildContext context, List categories) {
    return Row(
      children: [
        // Sol sütun (Avatar + Takvim)
        Expanded(
          flex: 2,
          child: Column(
            children: [
              _buildAvatar('https://i.pravatar.cc/150?img=5', size: 120),
              const SizedBox(height: 16),
              const Expanded(child: CalendarWidget()),
            ],
          ),
        ),

        const SizedBox(width: 16),

        // Orta sütun (Logo + Kullanıcı + Kategoriler)
        Expanded(
          flex: 5,
          child: Column(
            children: [
              // Logo ve isim
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _buildLogo(size: 130),
                  const SizedBox(width: 24),
                  Column(
                    children: [
                      NeonContainer(
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                        borderRadius: 20,
                        child: Text(
                          'DEST-OS ARES',
                          style: GoogleFonts.orbitron(
                            color: const Color(0xFF00BFFF),
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 2.5,
                          ),
                        ),
                      ),
                      const SizedBox(height: 14),
                      _buildUserName(isTablet: true),
                    ],
                  ),
                ],
              ),

              const SizedBox(height: 20),

              // Kategori butonları - 2 satır x 4
              Expanded(
                child: Column(
                  children: [
                    Expanded(
                      child: Row(
                        children: categories.take(4).map((cat) {
                          return Expanded(
                            child: Padding(
                              padding: const EdgeInsets.all(6),
                              child: CategoryButton(
                                title: cat['title'] as String,
                                icon: cat['icon'] as IconData,
                                onTap: () => _openCategory(context, cat['title'] as String),
                                onAdd: () => _openAdd(context, cat['title'] as String),
                              ),
                            ),
                          );
                        }).toList(),
                      ),
                    ),
                    Expanded(
                      child: Row(
                        children: categories.skip(4).map((cat) {
                          return Expanded(
                            child: Padding(
                              padding: const EdgeInsets.all(6),
                              child: CategoryButton(
                                title: cat['title'] as String,
                                icon: cat['icon'] as IconData,
                                onTap: () => _openCategory(context, cat['title'] as String),
                                onAdd: () => _openAdd(context, cat['title'] as String),
                              ),
                            ),
                          );
                        }).toList(),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),

        const SizedBox(width: 16),

        // Sağ sütun (Avatar + Hava)
        Expanded(
          flex: 2,
          child: Column(
            children: [
              _buildAvatar('https://i.pravatar.cc/150?img=12', size: 120),
              const SizedBox(height: 16),
              const Expanded(child: WeatherWidget()),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildAvatar(String url, {double size = 90}) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(color: const Color(0xFF00BFFF), width: 2.5),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF00BFFF).withOpacity(0.5),
            blurRadius: 18,
            spreadRadius: 2,
          ),
        ],
      ),
      child: ClipOval(
        child: Image.network(
          url,
          fit: BoxFit.cover,
          errorBuilder: (_, __, ___) => Container(
            color: const Color(0xFF0A1A2F),
            child: Icon(Icons.person, color: const Color(0xFF00BFFF), size: size * 0.45),
          ),
        ),
      ),
    );
  }

  Widget _buildLogo({double size = 110}) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: const Color(0xFF00BFFF), width: 2.5),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF00BFFF).withOpacity(0.45),
            blurRadius: 22,
            spreadRadius: 3,
          ),
        ],
        gradient: const RadialGradient(
          colors: [Color(0xFF0A2A4A), Color(0xFF02050A)],
        ),
      ),
      child: Center(
        child: Icon(
          Icons.remove_red_eye,
          color: const Color(0xFF00BFFF),
          size: size * 0.45,
        ),
      ),
    );
  }

  Widget _buildUserName({bool isTablet = false}) {
    return NeonContainer(
      padding: EdgeInsets.symmetric(
        horizontal: isTablet ? 18 : 12,
        vertical: isTablet ? 10 : 8,
      ),
      borderRadius: 12,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.person, color: const Color(0xFF00BFFF), size: isTablet ? 20 : 16),
          const SizedBox(width: 8),
          Text(
            'KULLANICI ADI',
            style: TextStyle(
              color: Colors.white.withOpacity(0.55),
              fontSize: isTablet ? 12 : 10,
            ),
          ),
          const SizedBox(width: 10),
          Text(
            'İbrahim Halil Ezen',
            style: TextStyle(
              color: Colors.white,
              fontSize: isTablet ? 15 : 13,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}
