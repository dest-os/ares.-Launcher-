import 'package:flutter/material.dart';
import 'neon_container.dart';

class StatusBarWidget extends StatelessWidget {
  const StatusBarWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return NeonContainer(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      borderRadius: 20,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.wifi, color: Colors.white.withOpacity(0.9), size: 18),
          const SizedBox(width: 10),
          Icon(Icons.bluetooth, color: Colors.white.withOpacity(0.9), size: 18),
          const SizedBox(width: 10),
          Icon(Icons.signal_cellular_alt, color: Colors.white.withOpacity(0.9), size: 18),
          const SizedBox(width: 10),
          Icon(Icons.battery_std, color: Colors.white.withOpacity(0.9), size: 18),
          const SizedBox(width: 4),
          Text(
            '65%',
            style: TextStyle(
              color: Colors.white.withOpacity(0.9),
              fontSize: 13,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
}
