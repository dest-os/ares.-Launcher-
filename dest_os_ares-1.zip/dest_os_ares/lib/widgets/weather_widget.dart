import 'package:flutter/material.dart';
import '../services/weather_service.dart';
import 'neon_container.dart';

class WeatherWidget extends StatefulWidget {
  const WeatherWidget({super.key});

  @override
  State<WeatherWidget> createState() => _WeatherWidgetState();
}

class _WeatherWidgetState extends State<WeatherWidget> {
  WeatherData? _weather;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadWeather();
  }

  Future<void> _loadWeather() async {
    setState(() => _loading = true);
    final data = await WeatherService().getWeather();
    if (mounted) {
      setState(() {
        _weather = data;
        _loading = false;
      });
    }
  }

  String _capitalize(String s) {
    if (s.isEmpty) return s;
    return s[0].toUpperCase() + s.substring(1);
  }

  @override
  Widget build(BuildContext context) {
    return NeonContainer(
      padding: const EdgeInsets.all(12),
      borderRadius: 14,
      child: _loading
          ? const SizedBox(
              height: 120,
              child: Center(
                child: CircularProgressIndicator(color: Color(0xFF00BFFF), strokeWidth: 2),
              ),
            )
          : _weather == null
              ? const Text('Hava alınamadı', style: TextStyle(color: Colors.white70))
              : Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.location_on, color: Color(0xFF00BFFF), size: 14),
                        const SizedBox(width: 4),
                        Text(
                          _weather!.city,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        const Icon(Icons.wb_sunny_outlined, color: Color(0xFFFFD700), size: 28),
                        const SizedBox(width: 8),
                        Text(
                          '${_weather!.temp.round()}°C',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 26,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    Text(
                      _capitalize(_weather!.description),
                      style: TextStyle(color: Colors.white.withOpacity(0.8), fontSize: 12),
                    ),
                    const SizedBox(height: 8),
                    _infoRow(Icons.thermostat, 'Hissedilen', '${_weather!.feelsLike.round()}°C'),
                    _infoRow(Icons.water_drop, 'Nem', '%${_weather!.humidity}'),
                    _infoRow(Icons.air, 'Rüzgar', '${_weather!.windSpeed.round()} km/sa'),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Icon(Icons.refresh, color: Colors.white.withOpacity(0.5), size: 12),
                        const SizedBox(width: 4),
                        Text(
                          'Güncellendi ${_weather!.updatedAt.hour.toString().padLeft(2, '0')}:${_weather!.updatedAt.minute.toString().padLeft(2, '0')}',
                          style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 10),
                        ),
                      ],
                    ),
                  ],
                ),
    );
  }

  Widget _infoRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 2),
      child: Row(
        children: [
          Icon(icon, color: const Color(0xFF00BFFF).withOpacity(0.7), size: 13),
          const SizedBox(width: 6),
          Text(
            label,
            style: TextStyle(color: Colors.white.withOpacity(0.7), fontSize: 11),
          ),
          const Spacer(),
          Text(
            value,
            style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w500),
          ),
        ],
      ),
    );
  }
}
