import 'package:flutter/material.dart';
import '../models/shortcut.dart';
import '../services/shortcut_service.dart';
import 'neon_container.dart';

class ShortcutSheet extends StatefulWidget {
  final String category;

  const ShortcutSheet({super.key, required this.category});

  @override
  State<ShortcutSheet> createState() => _ShortcutSheetState();
}

class _ShortcutSheetState extends State<ShortcutSheet> {
  List<ShortcutItem> _shortcuts = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final list = await ShortcutService().getShortcuts(widget.category);
    if (mounted) {
      setState(() {
        _shortcuts = list;
        _loading = false;
      });
    }
  }

  Future<void> _remove(String id) async {
    await ShortcutService().removeShortcut(id);
    await _load();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('Kısayol kaldırıldı (uygulama silinmedi)'),
          backgroundColor: Colors.black87,
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  void _showAddDialog() {
    final available = ShortcutService.getAvailableApps(widget.category);
    final existingIds = _shortcuts.map((s) => s.id).toSet();
    final toShow = available.where((a) => !existingIds.contains(a.id)).toList();

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (ctx) {
        return Container(
          margin: const EdgeInsets.all(12),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: const Color(0xFF0A0E17),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: const Color(0xFF00BFFF).withOpacity(0.6), width: 1.5),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF00BFFF).withOpacity(0.3),
                blurRadius: 20,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                '${widget.category} - Uygulama Ekle',
                style: const TextStyle(
                  color: Color(0xFF00BFFF),
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              if (toShow.isEmpty)
                const Padding(
                  padding: EdgeInsets.all(20),
                  child: Text(
                    'Eklenebilecek uygulama kalmadı',
                    style: TextStyle(color: Colors.white70),
                  ),
                )
              else
                Flexible(
                  child: ListView.builder(
                    shrinkWrap: true,
                    itemCount: toShow.length,
                    itemBuilder: (_, i) {
                      final app = toShow[i];
                      return ListTile(
                        leading: Text(app.icon, style: const TextStyle(fontSize: 24)),
                        title: Text(app.name, style: const TextStyle(color: Colors.white)),
                        trailing: const Icon(Icons.add_circle_outline, color: Color(0xFF00BFFF)),
                        onTap: () async {
                          await ShortcutService().addShortcut(app);
                          Navigator.pop(ctx);
                          await _load();
                        },
                      );
                    },
                  ),
                ),
              const SizedBox(height: 8),
              TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('Kapat', style: TextStyle(color: Colors.white54)),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF0A0E17),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFF00BFFF).withOpacity(0.6), width: 1.5),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF00BFFF).withOpacity(0.3),
            blurRadius: 20,
            spreadRadius: 2,
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              Text(
                widget.category,
                style: const TextStyle(
                  color: Color(0xFF00BFFF),
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1,
                ),
              ),
              const Spacer(),
              IconButton(
                onPressed: _showAddDialog,
                icon: const Icon(Icons.add_circle, color: Color(0xFF00BFFF), size: 28),
              ),
              IconButton(
                onPressed: () => Navigator.pop(context),
                icon: const Icon(Icons.close, color: Colors.white54),
              ),
            ],
          ),
          const Divider(color: Color(0xFF00BFFF), height: 20),
          if (_loading)
            const Padding(
              padding: EdgeInsets.all(30),
              child: CircularProgressIndicator(color: Color(0xFF00BFFF)),
            )
          else if (_shortcuts.isEmpty)
            Padding(
              padding: const EdgeInsets.all(30),
              child: Column(
                children: [
                  Icon(Icons.apps, color: Colors.white.withOpacity(0.3), size: 48),
                  const SizedBox(height: 12),
                  Text(
                    'Henüz kısayol yok\n+ butonuna basarak ekle',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white.withOpacity(0.5)),
                  ),
                ],
              ),
            )
          else
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 4,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 0.85,
              ),
              itemCount: _shortcuts.length,
              itemBuilder: (_, i) {
                final item = _shortcuts[i];
                return NeonContainer(
                  onTap: () {
                    // Gerçek uygulamayı açmak için burada intent kullanılabilir
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('${item.name} açılıyor... (demo)'),
                        backgroundColor: Colors.black87,
                        behavior: SnackBarBehavior.floating,
                      ),
                    );
                  },
                  onLongPress: () => _remove(item.id),
                  borderRadius: 12,
                  padding: const EdgeInsets.all(8),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(item.icon, style: const TextStyle(fontSize: 28)),
                      const SizedBox(height: 6),
                      Text(
                        item.name,
                        textAlign: TextAlign.center,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          const SizedBox(height: 8),
          Text(
            'Uzun bas = Kısayolu kaldır',
            style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 11),
          ),
        ],
      ),
    );
  }
}
