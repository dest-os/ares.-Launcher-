package com.destos.ares

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
